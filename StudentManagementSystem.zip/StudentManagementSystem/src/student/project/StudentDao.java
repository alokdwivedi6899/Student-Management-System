package student.project;

import java.sql.*;
import student.project.DBConnection;

public class StudentDao {

    public void addStudent(String name, int age, String course) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO students(name, age, course) VALUES (?, ?, ?)"
            );
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, course);
            ps.executeUpdate();
            System.out.println("Student Added Successfully!\n");
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    public void viewStudents() {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM students");
            System.out.println("ID | NAME | AGE | COURSE");
            System.out.println("--------------------------------");
            while (rs.next()) {
                System.out.println(
                    rs.getInt(1) + " | " + rs.getString(2) + " | " +
                    rs.getInt(3) + " | " + rs.getString(4)
                );
            }
            System.out.println();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    public void deleteStudent(int id) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Student Deleted Successfully!\n");
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
